#!/usr/bin/env python3

import sys

try:
    dict1 = {}

    for arg in sys.argv[1:]:
        s1,s2 = arg.split(':')
        dict1[s1] = int(s2)

    for key,value in dict1.items():
        pay0 = value - value * 0.165
        pay = pay0 - 5000
        if pay < 0:
            tax = 0
        elif 0 <= pay < 3000:
            tax = pay * 0.03
        elif 3000 <= pay < 12000:
            tax = pay * 0.1 -210
        elif 12000 <= pay < 25000:
            tax = pay * 0.2 -1410
        elif 25000 <= pay < 35000:
            tax = pay * 0.25 - 2660
        elif 35000 <= pay < 55000:
            tax = pay * 0.30 - 4410
        elif 55000 <= pay < 80000:
            tax = pay * 0.35 - 7160
        else:
            tax = pay * 0.45 - 15160
        final = pay0 -tax
        print(key+':{:.2f}'.format(final))
except (AttributeError,AssertionError,ValueError):
    print('Parameter Error')
